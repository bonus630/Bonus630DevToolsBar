using System;


namespace $safeprojectname$
{
	[System.AttributeUsage(System.AttributeTargets.Class)]
	public class CgsAddInModule : System.Attribute { };

	[System.AttributeUsage(System.AttributeTargets.Class)]
	public class ModulePath : System.Attribute 
	{
		private string _value;

		public ModulePath(string value)
		{
			_value = value;
		}

		public string Value
		{
			get { return _value; }
		}
	};

	[System.AttributeUsage(System.AttributeTargets.Constructor)]
	public class CgsAddInConstructor : System.Attribute { };

	[System.AttributeUsage(System.AttributeTargets.Method)]
	public class CgsAddInMacro : System.Attribute { };
}