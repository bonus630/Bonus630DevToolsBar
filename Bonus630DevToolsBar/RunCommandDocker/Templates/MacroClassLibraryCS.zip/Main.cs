﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Corel.Interop.VGCore;

namespace $safeprojectname$
{
	
	[CgsAddInModule]
	[ModulePath(@"$ModulePath$")]
	public class Main
    {
		private Corel.Interop.VGCore.Application corelApp;
		[CgsAddInConstructor]
		public Main(object _app)
		{
			corelApp = _app as Corel.Interop.VGCore.Application;
		}
		[CgsAddInMacro]
       	public void NewDocument()
       	{
         	corelApp.CreateDocument();
       	}
	}
}
