<System.AttributeUsage(System.AttributeTargets.[Class])>
    Public Class CgsAddInModule
        Inherits System.Attribute
    End Class
<System.AttributeUsage(System.AttributeTargets.Class)>
	Public Class ModulePath 
        Inherits System.Attribute 
	    Private _value As String

        Sub New(ByVal value As String)
            _value = value
        End Sub

        Public ReadOnly Property Value As String
            Get
                Return _value
            End Get
        End Property
	End Class
<System.AttributeUsage(System.AttributeTargets.Constructor)>
    Public Class CgsAddInConstructor
        Inherits System.Attribute
    End Class

<System.AttributeUsage(System.AttributeTargets.Method)>
    Public Class CgsAddInMacro
        Inherits System.Attribute
    End Class