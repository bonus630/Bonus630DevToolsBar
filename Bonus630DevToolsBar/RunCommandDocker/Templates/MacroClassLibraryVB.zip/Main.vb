﻿<CgsAddInModule>
<ModulePath("$ModulePath$")>
Public Class Main
    Private corelApp As Corel.Interop.VGCore.Application

    <CgsAddInConstructor>
    Sub New(ByVal app As Object)
        corelApp = TryCast(app, Corel.Interop.VGCore.Application)
    End Sub

    <CgsAddInMacro>
    Sub NewDocument()
        corelApp.CreateDocument()
    End Sub

End Class

